# Food SQLite Demo
- This tutorial we will save text from EditText and Image from gallery into SQLite database. So here is the complete step by step tutorial for Insert data into SQLite database in android using EditText and ImageView and then show all data to custom gridview, update & delete data in sqlite
- Video tutorials: https://goo.gl/MkAtcE
- Demo:

> ![alt tag](https://github.com/quocnguyenvan/food-sqlite-demo/blob/master/demo/food_sqlite.png)

